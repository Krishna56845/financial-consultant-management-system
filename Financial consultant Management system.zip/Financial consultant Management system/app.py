from flask import (
    Flask, render_template, request, redirect,
    url_for, flash, jsonify, make_response
)
from flask_sqlalchemy import SQLAlchemy
import os, io, csv, sqlite3
from datetime import datetime, date, time as time_cls

app = Flask(__name__)
app.secret_key = "supersecretkey123"

# ================================
# DATABASE CONFIG
# ================================
base_dir = os.path.abspath(os.path.dirname(__file__))
db_path = os.path.join(base_dir, "consultant_system.db")

app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///" + db_path
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)


# ================================
# MODELS
# ================================
class Consultant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150), nullable=False)
    expertise = db.Column(db.String(200), nullable=False)  # financial domain
    financial_specialization = db.Column(db.String(250))
    license_certifications = db.Column(db.String(250))
    years_experience = db.Column(db.Integer)
    consultation_fee = db.Column(db.Float)
    portfolio_management = db.Column(db.Boolean, default=False)
    preferred_client_segments = db.Column(db.String(250))
    phone = db.Column(db.String(50))
    email = db.Column(db.String(120))


class Client(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(150))
    project = db.Column(db.String(200))
    phone = db.Column(db.String(50))
    email = db.Column(db.String(150))
    income = db.Column(db.Float)
    net_worth = db.Column(db.Float)
    risk_tolerance = db.Column(db.String(50))
    financial_goals = db.Column(db.String(500))
    current_portfolio = db.Column(db.String(500))


class Payment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"))
    amount = db.Column(db.Float, nullable=False)
    payment_method = db.Column(db.String(50), default="Other")  # NEW FIELD
    date = db.Column(db.DateTime, default=datetime.utcnow)
    note = db.Column(db.String(300))


class Appointment(db.Model):  # BOOKING SYSTEM
    id = db.Column(db.Integer, primary_key=True)
    client_id = db.Column(db.Integer, db.ForeignKey("client.id"), nullable=False)
    consultant_id = db.Column(db.Integer, db.ForeignKey("consultant.id"), nullable=False)
    date = db.Column(db.Date, nullable=False)
    time = db.Column(db.Time, nullable=False)
    status = db.Column(db.String(50), default="Scheduled")  # Scheduled / Completed / Cancelled


# ================================
# MIGRATION (OLD DB KE LIYE)
# ================================
def migrate():
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    def col_exists(table, col):
        cur.execute(f"PRAGMA table_info({table})")
        return col in [r[1] for r in cur.fetchall()]

    columns = [
        ("consultant", "financial_specialization", "TEXT"),
        ("consultant", "license_certifications", "TEXT"),
        ("consultant", "years_experience", "INTEGER"),
        ("consultant", "consultation_fee", "REAL"),
        ("consultant", "portfolio_management", "INTEGER"),
        ("consultant", "preferred_client_segments", "TEXT"),
        ("client", "income", "REAL"),
        ("client", "net_worth", "REAL"),
        ("client", "risk_tolerance", "TEXT"),
        ("client", "financial_goals", "TEXT"),
        ("client", "current_portfolio", "TEXT"),
        ("payment", "payment_method", "TEXT"),  # NEW COLUMN FOR OLD DB
    ]

    for table, col, t in columns:
        if not col_exists(table, col):
            try:
                cur.execute(f"ALTER TABLE " + table + " ADD COLUMN " + col + " " + t)
            except Exception as e:
                print("Could not add column", table, col, e)

    conn.commit()
    conn.close()


with app.app_context():
    db.create_all()
    migrate()


# ================================
# DASHBOARD
# ================================
@app.route("/")
def index():
    consultants = Consultant.query.all()
    clients = Client.query.all()
    return render_template("dashboard.html", consultants=consultants, clients=clients)


# ================================
# CONSULTANTS LIST + SEARCH
# ================================
@app.route("/view_consultants")
def view_consultants():
    q = request.args.get("q", "").strip()
    if q:
        consultants = Consultant.query.filter(
            (Consultant.name.like(f"%{q}%"))
            | (Consultant.expertise.like(f"%{q}%"))
            | (Consultant.financial_specialization.like(f"%{q}%"))
        ).all()
    else:
        consultants = Consultant.query.all()

    return render_template("view_consultants.html", consultants=consultants, q=q)


# ================================
# CLIENTS LIST + SEARCH
# ================================
@app.route("/view_clients")
def view_clients():
    q = request.args.get("q", "").strip()
    if q:
        clients = Client.query.filter(
            (Client.name.like(f"%{q}%"))
            | (Client.project.like(f"%{q}%"))
        ).all()
    else:
        clients = Client.query.all()

    return render_template("view_clients.html", clients=clients, q=q)


# ================================
# ADD / EDIT / DELETE CONSULTANT
# ================================
@app.route("/add_consultant", methods=["GET", "POST"])
def add_consultant():
    if request.method == "POST":
        years = request.form.get("years_experience")
        fee = request.form.get("consultation_fee")
        c = Consultant(
            name=request.form["name"],
            expertise=request.form["expertise"],
            phone=request.form.get("phone"),
            email=request.form.get("email"),
            financial_specialization=request.form.get("financial_specialization"),
            license_certifications=request.form.get("license_certifications"),
            years_experience=int(years) if years else None,
            consultation_fee=float(fee) if fee else None,
            portfolio_management=bool(request.form.get("portfolio_management")),
            preferred_client_segments=request.form.get("preferred_client_segments"),
        )
        db.session.add(c)
        db.session.commit()
        flash("Consultant added", "success")
        return redirect(url_for("view_consultants"))
    return render_template("add_consultant.html")


@app.route("/edit_consultant/<int:consultant_id>", methods=["GET", "POST"])
def edit_consultant(consultant_id):
    c = Consultant.query.get_or_404(consultant_id)
    if request.method == "POST":
        years = request.form.get("years_experience")
        fee = request.form.get("consultation_fee")
        c.name = request.form["name"]
        c.expertise = request.form["expertise"]
        c.phone = request.form.get("phone")
        c.email = request.form.get("email")
        c.financial_specialization = request.form.get("financial_specialization")
        c.license_certifications = request.form.get("license_certifications")
        c.years_experience = int(years) if years else None
        c.consultation_fee = float(fee) if fee else None
        c.portfolio_management = bool(request.form.get("portfolio_management"))
        c.preferred_client_segments = request.form.get("preferred_client_segments")
        db.session.commit()
        flash("Consultant updated", "success")
        return redirect(url_for("view_consultants"))
    return render_template("edit_consultant.html", c=c)


@app.route("/delete_consultant/<int:consultant_id>", methods=["POST"])
def delete_consultant(consultant_id):
    c = Consultant.query.get_or_404(consultant_id)
    db.session.delete(c)
    db.session.commit()
    flash("Consultant deleted", "warning")
    return redirect(url_for("view_consultants"))


# ================================
# ADD / EDIT / DELETE CLIENT
# ================================
@app.route("/add_client", methods=["GET", "POST"])
def add_client():
    if request.method == "POST":
        income = request.form.get("income")
        nw = request.form.get("net_worth")
        cl = Client(
            name=request.form["name"],
            project=request.form["project"],
            phone=request.form.get("phone"),
            email=request.form.get("email"),
            income=float(income) if income else None,
            net_worth=float(nw) if nw else None,
            risk_tolerance=request.form.get("risk_tolerance"),
            financial_goals=request.form.get("financial_goals"),
            current_portfolio=request.form.get("current_portfolio"),
        )
        db.session.add(cl)
        db.session.commit()
        flash("Client added", "success")
        return redirect(url_for("view_clients"))
    return render_template("add_client.html")


@app.route("/edit_client/<int:client_id>", methods=["GET", "POST"])
def edit_client(client_id):
    c = Client.query.get_or_404(client_id)
    if request.method == "POST":
        income = request.form.get("income")
        nw = request.form.get("net_worth")
        c.name = request.form["name"]
        c.project = request.form["project"]
        c.phone = request.form.get("phone")
        c.email = request.form.get("email")
        c.income = float(income) if income else None
        c.net_worth = float(nw) if nw else None
        c.risk_tolerance = request.form.get("risk_tolerance")
        c.financial_goals = request.form.get("financial_goals")
        c.current_portfolio = request.form.get("current_portfolio")
        db.session.commit()
        flash("Client updated", "success")
        return redirect(url_for("view_clients"))
    return render_template("edit_client.html", c=c)


@app.route("/delete_client/<int:client_id>", methods=["POST"])
def delete_client(client_id):
    c = Client.query.get_or_404(client_id)
    db.session.delete(c)
    db.session.commit()
    flash("Client deleted", "warning")
    return redirect(url_for("view_clients"))


# ================================
# PAYMENTS
# ================================
@app.route("/payments")
def payments():
    payments = Payment.query.order_by(Payment.date.desc()).all()
    clients = {c.id: c for c in Client.query.all()}
    return render_template("payments.html", payments=payments, clients=clients)


@app.route("/add_payment", methods=["POST"])
def add_payment():
    p = Payment(
        client_id=int(request.form["client_id"]),
        amount=float(request.form["amount"]),
        payment_method=request.form.get("payment_method") or "Other",
        note=request.form.get("note"),
    )
    db.session.add(p)
    db.session.commit()
    flash("Payment recorded", "success")
    return redirect(url_for("payments"))


# ================================
# APPOINTMENTS (BOOKING SYSTEM)
# ================================
@app.route("/appointments", methods=["GET", "POST"])
def appointments():
    if request.method == "POST":
        client_id = int(request.form["client_id"])
        consultant_id = int(request.form["consultant_id"])
        date_str = request.form["date"]
        time_str = request.form["time"]
        status = request.form.get("status") or "Scheduled"

        appt_date = datetime.strptime(date_str, "%Y-%m-%d").date()
        appt_time = datetime.strptime(time_str, "%H:%M").time()

        appt = Appointment(
            client_id=client_id,
            consultant_id=consultant_id,
            date=appt_date,
            time=appt_time,
            status=status,
        )
        db.session.add(appt)
        db.session.commit()
        flash("Appointment booked", "success")
        return redirect(url_for("appointments"))

    appointments_list = Appointment.query.order_by(
        Appointment.date, Appointment.time
    ).all()
    clients = {c.id: c for c in Client.query.all()}
    consultants = {c.id: c for c in Consultant.query.all()}
    return render_template(
        "appointments.html",
        appointments=appointments_list,
        clients=clients,
        consultants=consultants,
    )


@app.route("/delete_appointment/<int:appointment_id>", methods=["POST"])
def delete_appointment(appointment_id):
    appt = Appointment.query.get_or_404(appointment_id)
    db.session.delete(appt)
    db.session.commit()
    flash("Appointment deleted", "warning")
    return redirect(url_for("appointments"))


# ================================
# EXPORT CLIENTS CSV
# ================================
@app.route("/export_clients")
def export_clients():
    clients = Client.query.order_by(Client.name).all()
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(
        ["ID", "Name", "Project", "Phone", "Email", "Income", "Net Worth", "Risk"]
    )
    for c in clients:
        writer.writerow(
            [
                c.id,
                c.name,
                c.project,
                c.phone or "",
                c.email or "",
                c.income or "",
                c.net_worth or "",
                c.risk_tolerance or "",
            ]
        )
    response = make_response(output.getvalue())
    response.headers["Content-Disposition"] = "attachment; filename=clients.csv"
    response.headers["Content-type"] = "text/csv"
    return response


# ================================
# API STATS (OPTIONAL)
# ================================
@app.route("/api/stats")
def api_stats():
    consultants = Consultant.query.all()
    clients = Client.query.all()
    spec_counts = {}
    for c in consultants:
        specs = (c.financial_specialization or c.expertise or "").split(",")
        for s in specs:
            s = s.strip()
            if not s:
                continue
            spec_counts[s] = spec_counts.get(s, 0) + 1
    exp_buckets = {"0-2": 0, "3-5": 0, "6-10": 0, "10+": 0}
    for c in consultants:
        y = c.years_experience or 0
        if y <= 2:
            exp_buckets["0-2"] += 1
        elif y <= 5:
            exp_buckets["3-5"] += 1
        elif y <= 10:
            exp_buckets["6-10"] += 1
        else:
            exp_buckets["10+"] += 1
    return jsonify(
        {
            "spec_counts": spec_counts,
            "exp_buckets": exp_buckets,
            "total_consultants": len(consultants),
            "total_clients": len(clients),
        }
    )


# ================================
# RUN
# ================================
if __name__ == "__main__":
    app.run(debug=True)
